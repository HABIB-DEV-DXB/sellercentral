<?php
// Database configuration
$config['db_host'] = 'localhost';
$config['db_name'] = 'u437741037_barakath_mp';
$config['db_user'] = 'u437741037_barakath_mp';
$config['db_pass'] = 'A0L7OjWcqU1ipRBqhtI4';

// Email OTP configuration (you can update these when you're ready)
$config['smtp_host'] = 'your_smtp_host';
$config['smtp_user'] = 'your_smtp_username';
$config['smtp_pass'] = 'your_smtp_password';