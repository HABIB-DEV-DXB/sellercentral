<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barakath Seller</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/seller_landing.css">
</head>
<body>

<header class="landing-header">
    <div class="header-content">
        <a href="/" class="logo">Barakath Seller</a>
        <nav>
            <a href="/login" class="glass-button">Login</a>
        </nav>
    </div>
</header>
<main>