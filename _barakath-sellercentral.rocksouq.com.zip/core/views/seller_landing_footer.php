</main>
<footer>
    <p>&copy; <?php echo date('Y'); ?> Barakath Seller. All rights reserved.</p>
</footer>
<script src="/assets/js/landing.js"></script>
</body>
</html>